"""
Keyboard Manager - A GUI tool for managing keyboard layouts and KMonad configurations.

This module provides a Qt-based interface for:
- Managing KMonad configurations
- Configuring keyboard layouts
- Setting up system permissions
- Managing keyboard device selection
"""

import os
import re
import subprocess
import sys
import tempfile
from typing import Optional, Dict, List

# Qt imports
from PyQt6.QtCore import (
    QProcess, 
    QSettings, 
    QPropertyAnimation, 
    QEasingCurve, 
    QTimer, 
    Qt, 
    QPoint, 
    QMimeData
)
from PyQt6.QtGui import QDrag, QPixmap, QPainter, QTextCursor
from PyQt6.QtNetwork import QLocalSocket, QLocalServer
from PyQt6.QtWidgets import (
    QApplication, 
    QMainWindow, 
    QVBoxLayout, 
    QHBoxLayout,
    QWidget, 
    QPushButton, 
    QComboBox, 
    QTextEdit, 
    QLabel,
    QFileDialog, 
    QMessageBox, 
    QGroupBox, 
    QCheckBox,
    QWizard, 
    QWizardPage, 
    QProgressBar, 
    QSizePolicy
)

# Local imports
from .keyboard_layout import KeyboardLayout

class KeyboardManager(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # Initialize settings
        self.settings = QSettings("Compyutinator", "KeyboardManager")
        
        # Check if setup is needed
        if not self.check_setup():
            from .setup import SetupManager
            setup = SetupManager()
            success, msg = setup.check_requirements()
            if not success:
                reply = QMessageBox.question(
                    self, 
                    "Setup Required",
                    f"{msg}\nWould you like to run setup now?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.Yes:
                    success, msg = setup.setup_permissions()
                    if not success:
                        QMessageBox.critical(self, "Setup Failed", msg)
                        sys.exit(1)
                    else:
                        QMessageBox.information(
                            self, 
                            "Setup Complete", 
                            "Setup completed successfully. Please log out and back in."
                        )
                        sys.exit(0)
                else:
                    sys.exit(1)
        
        # Initialize UI
        self.init_ui()

    def check_setup(self) -> bool:
        """Check if setup is needed and run setup wizard if necessary."""
        if self.settings.value("setup_complete", False, type=bool):
            return True
        
        wizard = SetupWizard(self)
        if wizard.exec() == QWizard.DialogCode.Accepted:
            self.settings.setValue("setup_complete", True)
            return True
        return False

    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle("Keyboard Manager")
        
        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create keyboard layout widget
        self.keyboard_layout = KeyboardLayout(self)
        main_layout.addWidget(self.keyboard_layout)
        
        # Create controls
        controls_group = QGroupBox("Controls")
        controls_layout = QHBoxLayout()
        
        # Add buttons
        load_button = QPushButton("Load Config")
        save_button = QPushButton("Save Config")
        apply_button = QPushButton("Apply")
        
        controls_layout.addWidget(load_button)
        controls_layout.addWidget(save_button)
        controls_layout.addWidget(apply_button)
        
        controls_group.setLayout(controls_layout)
        main_layout.addWidget(controls_group)
        
        # Set window size
        self.setMinimumSize(800, 600)

class SetupWizard(QWizard):
    """Setup wizard for first-time configuration."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Keyboard Manager Setup")
        self.addPage(self.create_intro_page())
        self.addPage(self.create_module_page())
        self.addPage(self.create_permissions_page())
        self.addPage(self.create_finish_page())
        
    def create_intro_page(self):
        page = QWizardPage()
        page.setTitle("Welcome to Keyboard Manager")
        layout = QVBoxLayout()
        label = QLabel(
            "This wizard will help you set up the required permissions and configurations. "
            "You will need administrator privileges to complete the setup."
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        page.setLayout(layout)
        return page
        
    def create_module_page(self):
        page = QWizardPage()
        page.setTitle("System Module Configuration")
        layout = QVBoxLayout()
        
        # Module status
        self.module_status = QLabel()
        layout.addWidget(self.module_status)
        
        # Load module button
        self.load_button = QPushButton("Load uinput Module")
        self.load_button.clicked.connect(self.load_uinput_module)
        layout.addWidget(self.load_button)
        
        # Persistent module checkbox
        self.persistent_check = QCheckBox("Load module at boot")
        self.persistent_check.setChecked(True)
        layout.addWidget(self.persistent_check)
        
        page.setLayout(layout)
        return page
        
    def create_permissions_page(self):
        page = QWizardPage()
        page.setTitle("User Permissions Setup")
        layout = QVBoxLayout()
        
        # Group status
        self.group_status = QLabel()
        layout.addWidget(self.group_status)
        
        # Setup permissions button
        self.perm_button = QPushButton("Setup Permissions")
        self.perm_button.clicked.connect(self.setup_permissions)
        layout.addWidget(self.perm_button)
        
        page.setLayout(layout)
        return page
        
    def create_finish_page(self):
        page = QWizardPage()
        page.setTitle("Setup Complete")
        layout = QVBoxLayout()
        label = QLabel(
            "Setup is complete! You will need to log out and back in "
            "for the group changes to take effect."
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        page.setLayout(layout)
        return page
        
    def load_uinput_module(self):
        """Load the uinput module and optionally make it persistent."""
        try:
            # Load module
            subprocess.run(['pkexec', 'modprobe', 'uinput'], check=True)
            
            # Make persistent if checked
            if self.persistent_check.isChecked():
                with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as temp:
                    temp.write('echo "uinput" > /etc/modules-load.d/uinput.conf\n')
                    script_path = temp.name
                os.chmod(script_path, 0o755)
                subprocess.run(['pkexec', script_path], check=True)
                os.unlink(script_path)
                
            self.module_status.setText("✓ Module loaded successfully")
            self.load_button.setEnabled(False)
            
        except subprocess.CalledProcessError as e:
            QMessageBox.critical(self, "Error", f"Failed to load module: {str(e)}")
            
    def setup_permissions(self):
        """Set up user groups and udev rules."""
        try:
            script_content = """#!/bin/bash
# Add user to groups
usermod -aG input $SUDO_USER
usermod -aG uinput $SUDO_USER

# Create udev rule
echo 'KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"' > /etc/udev/rules.d/99-kmonad.rules

# Reload udev rules
udevadm control --reload-rules
udevadm trigger
"""
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as temp:
                temp.write(script_content)
                script_path = temp.name
                
            os.chmod(script_path, 0o755)
            subprocess.run(['pkexec', script_path], check=True)
            os.unlink(script_path)
            
            self.group_status.setText("✓ Permissions set up successfully")
            self.perm_button.setEnabled(False)
            
        except subprocess.CalledProcessError as e:
            QMessageBox.critical(self, "Error", f"Failed to set up permissions: {str(e)}")

def main():
    """Entry point for the keyboard manager application."""
    app = QApplication(sys.argv)
    manager = KeyboardManager()
    manager.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()