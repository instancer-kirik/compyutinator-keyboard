"""
Setup script for compyutinator-keyboard.
Handles initial configuration, permissions, and system requirements.
"""

import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Tuple, Optional

class SetupManager:
    """Manages initial setup and configuration for the keyboard manager."""

    def __init__(self):
        self.config_dir = Path.home() / ".config" / "compyutinator-keyboard"
        self.kmonad_config_dir = Path.home() / ".config" / "kmonad"

    def check_requirements(self) -> Tuple[bool, str]:
        """
        Check if all required software and permissions are in place.
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            # Check for KMonad
            kmonad_version = subprocess.run(
                ['kmonad', '--version'], 
                capture_output=True, 
                text=True
            )
            if kmonad_version.returncode != 0:
                return False, "KMonad not found. Please install KMonad first."

            # Check for uinput module
            with open('/proc/modules') as f:
                if 'uinput' not in f.read():
                    return False, "uinput module not loaded. Run 'modprobe uinput' as root."

            # Check user groups
            groups = subprocess.run(
                ['groups'], 
                capture_output=True, 
                text=True
            ).stdout.split()
            if 'input' not in groups or 'uinput' not in groups:
                return False, "User not in required groups. Run setup_permissions()."

            return True, "All requirements met."

        except Exception as e:
            return False, f"Error checking requirements: {str(e)}"

    def setup_permissions(self) -> Tuple[bool, str]:
        """
        Set up required system permissions.
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            script_content = """#!/bin/bash
# Load uinput module
modprobe uinput

# Create uinput group if it doesn't exist
groupadd -f uinput

# Set uinput permissions
chmod 0660 /dev/uinput
chown root:input /dev/uinput

# Add user to groups
usermod -aG input $USER
usermod -aG uinput $USER

# Create udev rules
cat > /etc/udev/rules.d/99-kmonad.rules << EOL
KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"
EOL

# Reload udev rules
udevadm control --reload-rules
udevadm trigger
"""
            # Create temporary script
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as temp:
                temp.write(script_content)
                script_path = temp.name

            # Make script executable
            os.chmod(script_path, 0o755)

            # Run with pkexec
            result = subprocess.run(['pkexec', script_path], check=True)
            
            # Cleanup
            os.unlink(script_path)

            if result.returncode == 0:
                return True, "Permissions setup complete. Please log out and back in."
            else:
                return False, "Permission setup failed."

        except subprocess.CalledProcessError as e:
            return False, f"Error setting up permissions: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error during setup: {str(e)}"

    def create_config_dirs(self) -> Tuple[bool, str]:
        """
        Create necessary configuration directories.
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self.kmonad_config_dir.mkdir(parents=True, exist_ok=True)
            return True, "Configuration directories created successfully."
        except Exception as e:
            return False, f"Error creating config directories: {str(e)}"

def main():
    """Run the setup process."""
    setup = SetupManager()
    
    print("Checking requirements...")
    success, msg = setup.check_requirements()
    print(msg)
    
    if not success:
        print("\nSetting up permissions...")
        success, msg = setup.setup_permissions()
        print(msg)
        
        if not success:
            print("Setup failed. Please check the error messages above.")
            sys.exit(1)
    
    print("\nCreating configuration directories...")
    success, msg = setup.create_config_dirs()
    print(msg)
    
    if success:
        print("\nSetup completed successfully!")
    else:
        print("\nSetup failed. Please check the error messages above.")
        sys.exit(1)

if __name__ == "__main__":
    main() 