"""
Keyboard Layout Widget for visualizing and editing keyboard configurations.
"""

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QLabel, QVBoxLayout, QComboBox,
    QPushButton, QTextEdit, QCheckBox, QFileDialog, QSystemTrayIcon, QMenu, QMessageBox
)
from PyQt6.QtCore import Qt, QPoint, QPropertyAnimation, QEasingCurve, QMimeData
from PyQt6.QtGui import QPainter, QPen, QColor, QPixmap, QDrag, QIcon
import os
import re
import subprocess
import tempfile
from PyQt6.QtCore import QProcess
from PyQt6.QtWidgets import QApplication

class KeyboardLayout(QWidget):
    """Widget for displaying and editing keyboard layouts."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.layout.setSpacing(4)
        self.layout.setContentsMargins(10, 10, 10, 10)
        self.dragging = False
        self.drag_source = None
        self.drag_source_row = None
        self.active_row = None
        self.row_states = {}  # Store current state of each row
        self.setAcceptDrops(True)
        
        # Define default layouts first
        self.default_layout = {
            "Function": ["esc", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12"],
            "Number": ["grv", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "mins", "eql", "bspc"],
            "QWERTY": ["tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "lbrc", "rbrc", "bsls"],
            "Home": ["caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", "scln", "quot", "ret"],
            "Shift": ["lsft", "z", "x", "c", "v", "b", "n", "m", "comm", "dot", "slsh", "rsft"],
            "Control": ["lctl", "lmet", "lalt", "spc", "ralt", "rmet", "menu", "rctl"]
        }
        
        # Add device selection
        self.device_combo = QComboBox()
        self.refresh_button = QPushButton("Refresh Devices")
        self.refresh_button.clicked.connect(self.refresh_devices)
        
        device_layout = QHBoxLayout()
        device_layout.addWidget(QLabel("Keyboard Device:"))
        device_layout.addWidget(self.device_combo)
        device_layout.addWidget(self.refresh_button)
        self.layout.addLayout(device_layout)
        
        # Add layout selector
        layout_selector = QHBoxLayout()
        layout_selector.addWidget(QLabel("Base Layout:"))
        self.layout_combo = QComboBox()
        self.layout_combo.addItems(["QWERTY", "Colemak", "Dvorak"])
        self.layout_combo.currentTextChanged.connect(self.change_layout)
        layout_selector.addWidget(self.layout_combo)
        self.layout.insertLayout(1, layout_selector)
        
        # Now create keyboard layout
        self.create_keyboard_layout()
        
        # Add KMonad config view
        self.config_edit = QTextEdit()
        self.config_edit.setMinimumHeight(200)
        self.layout.addWidget(self.config_edit)
        
        # Add controls
        controls_layout = QHBoxLayout()
        
        self.offset_toggle = QCheckBox("Offset Layout")
        self.offset_toggle.stateChanged.connect(self.update_layout)
        controls_layout.addWidget(self.offset_toggle)
        
        self.load_button = QPushButton("Load Config")
        self.save_button = QPushButton("Save Config")
        self.load_button.clicked.connect(self.load_config)
        self.save_button.clicked.connect(self.save_config)
        
        controls_layout.addWidget(self.load_button)
        controls_layout.addWidget(self.save_button)
        
        # Add KMonad process management
        self.kmonad_process = None
        self.start_button = QPushButton("Start KMonad")
        self.start_button.clicked.connect(self.toggle_kmonad)
        controls_layout.addWidget(self.start_button)
        
        self.layout.addLayout(controls_layout)
        
        # Initialize
        self.refresh_devices()
        self.device_combo.currentTextChanged.connect(self.update_config)

        # Add special key functions
        self.special_keys = {
            "caps": "(tap-hold 200 esc lctl)",  # Caps is Esc when tapped, Ctrl when held
            "lsft": "(tap-hold-next 200 ( lsft)",  # Shift with tap-hold for parentheses
            "rsft": "(tap-hold-next 200 ) rsft)",
        }

        # Check for existing KMonad process on startup
        self.check_existing_kmonad()

        # Add system tray
        self.create_tray_icon()
        
        # Add minimize to tray option
        self.minimize_to_tray = QCheckBox("Minimize to Tray")
        self.minimize_to_tray.setChecked(True)
        controls_layout.addWidget(self.minimize_to_tray)

        # Add predefined layouts
        self.layouts = {
            "QWERTY": {
                "Function": ["esc", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12"],
                "Number": ["grv", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "mins", "eql", "bspc"],
                "QWERTY": ["tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "lbrc", "rbrc", "bsls"],
                "Home": ["caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", "scln", "quot", "ret"],
                "Shift": ["lsft", "z", "x", "c", "v", "b", "n", "m", "comm", "dot", "slsh", "rsft"],
                "Control": ["lctl", "lmet", "lalt", "spc", "ralt", "rmet", "menu", "rctl"]
            },
            "Colemak": {
                "Function": ["esc", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12"],
                "Number": ["grv", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "mins", "eql", "bspc"],
                "QWERTY": ["tab", "q", "w", "f", "p", "g", "j", "l", "u", "y", "scln", "lbrc", "rbrc", "bsls"],
                "Home": ["caps", "a", "r", "s", "t", "d", "h", "n", "e", "i", "o", "quot", "ret"],
                "Shift": ["lsft", "z", "x", "c", "v", "b", "k", "m", "comm", "dot", "slsh", "rsft"],
                "Control": ["lctl", "lmet", "lalt", "spc", "ralt", "rmet", "menu", "rctl"]
            }
        }

        # Add default KMonad configs
        self.kmonad_configs = {
            "QWERTY-Colemak": """
(defcfg
  input  (device-file "/dev/input/by-id/DEVICE_ID")
  output (uinput-sink "My KMonad output")
  fallthrough true
  allow-cmd true
)

(defsrc
  esc  f1   f2   f3   f4   f5   f6   f7   f8   f9   f10  f11  f12
  grv  1    2    3    4    5    6    7    8    9    0    -    =    bspc
  tab  q    w    e    r    t    y    u    i    o    p    [    ]    \\
  caps a    s    d    f    g    h    j    k    l    ;    '    ret
  lsft z    x    c    v    b    n    m    ,    .    /    rsft
  lctl lmet lalt           spc            ralt rmet menu rctl
)

(defalias
  cap (tap-hold 200 esc lctl)
)

(deflayer colemak
  esc  f1   f2   f3   f4   f5   f6   f7   f8   f9   f10  f11  f12
  grv  1    2    3    4    5    6    7    8    9    0    -    =    bspc
  tab  q    w    f    p    g    j    l    u    y    ;    [    ]    \\
  @cap a    r    s    t    d    h    n    e    i    o    '    ret
  lsft z    x    c    v    b    k    m    ,    .    /    rsft
  lctl lmet lalt           spc            ralt rmet menu rctl
)
"""
        }

        # Add row offsets for staggered layout
        self.row_offsets = {
            "Function": 0,
            "Number": 0,
            "QWERTY": 25,  # Quarter key offset
            "Home": 35,    # Third key offset
            "Shift": 45,   # Half key offset
            "Control": 15  # Small offset
        }

        # Add warning label if not already added
        self.warning_label = QLabel(self)
        self.warning_label.setStyleSheet("""
            QLabel {
                color: #ff6b6b;
                background-color: #2a2a2a;
                border: 1px solid #ff6b6b;
                border-radius: 4px;
                padding: 4px 8px;
            }
        """)
        self.warning_label.hide()

    def refresh_devices(self):
        """Refresh the list of available keyboard devices."""
        self.device_combo.clear()
        try:
            # Try to read from by-path first (better for built-in keyboards)
            result = subprocess.run(
                ['ls', '-l', '/dev/input/by-path'], 
                capture_output=True, 
                text=True
            )
            
            devices = result.stdout.splitlines()
            keyboard_devices = []
            
            # Filter keyboard devices
            for device in devices:
                if 'kbd' in device.lower() or 'keyboard' in device.lower():
                    # Get the actual device path
                    try:
                        path = device.split(' -> ')[1].strip()
                        full_path = f"/dev/input/by-path/{os.path.basename(device)}"
                        keyboard_devices.append(full_path)
                    except IndexError:
                        continue
            
            # Also check by-id for external keyboards
            try:
                id_devices = os.listdir('/dev/input/by-id')
                for device in id_devices:
                    if 'kbd' in device.lower() or 'keyboard' in device.lower():
                        full_path = f"/dev/input/by-id/{device}"
                        if full_path not in keyboard_devices:
                            keyboard_devices.append(full_path)
            except (PermissionError, FileNotFoundError):
                pass
            
            if keyboard_devices:
                for device in keyboard_devices:
                    self.device_combo.addItem(device)
            else:
                self.device_combo.addItem("No keyboard devices found")
                
        except subprocess.CalledProcessError:
            self.device_combo.addItem("Error accessing keyboard devices")
            self.warning_label.setText("Error accessing keyboard devices")
            self.warning_label.show()

    def update_config(self):
        """Update KMonad config with current layout and device."""
        device = self.device_combo.currentText()
        if not device or device.startswith("No ") or device.startswith("Error"):
            return
            
        config = f"""
(defcfg
  input  (device-file "{device}")
  output (uinput-sink "My KMonad output")
  fallthrough true
  allow-cmd true
)

;; Define modmap to ensure base layout is QWERTY
(defsrc
  {self.generate_layout_config(use_default=True)}
)

;; Define custom aliases for special key combinations
(defalias
  cap (tap-hold 200 esc lctl)  ;; Caps is Esc when tapped, Ctrl when held
  spl (tap-hold-next 200 ( lsft)",  # Left shift with opening parenthesis
  spr (tap-hold-next 200 ) rsft)",  ;; Right shift with closing parenthesis
)

;; Define the main layer
(deflayer default
  {self.generate_layout_config(use_special=True)}
)
"""
        self.config_edit.setText(config)

    def load_config(self):
        """Load KMonad config from file."""
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Load KMonad Config",
            os.path.expanduser("~/.config/kmonad"),
            "KMonad Config (*.kbd);;All Files (*.*)"
        )
        if filename:
            try:
                with open(filename, 'r') as f:
                    self.config_edit.setText(f.read())
                self.parse_config(self.config_edit.toPlainText())
            except Exception as e:
                self.warning_label.setText(f"Error loading config: {str(e)}")
                self.warning_label.show()

    def save_config(self):
        """Save KMonad config to file."""
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Save KMonad Config",
            os.path.expanduser("~/.config/kmonad"),
            "KMonad Config (*.kbd);;All Files (*.*)"
        )
        if filename:
            try:
                with open(filename, 'w') as f:
                    f.write(self.config_edit.toPlainText())
            except Exception as e:
                self.warning_label.setText(f"Error saving config: {str(e)}")
                self.warning_label.show()

    def generate_layout_config(self, use_default=False, use_special=False) -> str:
        """Generate KMonad layout configuration from current key positions."""
        layout = []
        for row in range(self.layout.count() - 3):  # Skip device selector and controls
            row_widget = self.layout.itemAt(row).widget()
            if isinstance(row_widget, QWidget):
                row_name = row_widget.property("row_name")
                row_layout = row_widget.layout()
                row_keys = []
                
                if use_default and row_name in self.default_layout:
                    row_keys = self.default_layout[row_name]
                else:
                    for i in range(row_layout.count() - 1):  # Skip stretch
                        key_block = row_layout.itemAt(i).widget()
                        if isinstance(key_block, KeyBlock):
                            key = key_block.key if key_block.key != " " else "_"
                            if use_special and key in self.special_keys:
                                key = self.special_keys[key]
                            row_keys.append(key)
                            
                layout.append(" ".join(row_keys))
        return "\n  ".join(layout)

    def create_keyboard_layout(self):
        """Create initial empty keyboard layout."""
        # Define row configurations with explicit max lengths
        self.row_configs = [
            {"name": "Function", "length": 13},
            {"name": "Number", "length": 14},
            {"name": "QWERTY", "length": 14},
            {"name": "Home", "length": 13},
            {"name": "Shift", "length": 12},
            {"name": "Control", "length": 8}
        ]
        
        # Create rows
        for config in self.row_configs:
            row_widget = QWidget()
            row_widget.setProperty("row_name", config["name"])
            row_widget.setProperty("max_length", config["length"])
            row_layout = QHBoxLayout(row_widget)
            row_layout.setSpacing(2)
            row_layout.setContentsMargins(2, 2, 2, 2)
            
            # Create key blocks with default layout
            default_keys = self.default_layout[config["name"]]
            for i in range(config["length"]):
                key = default_keys[i] if i < len(default_keys) else " "
                key_block = KeyBlock(key, self)
                key_block.setText(key)  # Set visible text
                row_layout.addWidget(key_block)
            
            row_layout.addStretch()
            self.layout.addWidget(row_widget)

    def toggle_kmonad(self):
        """Start or stop KMonad process."""
        if self.kmonad_process is None or self.kmonad_process.state() == QProcess.NotRunning:
            # Kill any existing kmonad processes first
            self.kill_existing_kmonad()
            
            # Save current config to temp file
            config_file = os.path.join(tempfile.gettempdir(), "temp_kmonad.kbd")
            try:
                with open(config_file, 'w') as f:
                    f.write(self.config_edit.toPlainText())
                
                # Start KMonad process
                self.kmonad_process = QProcess()
                self.kmonad_process.finished.connect(self.on_kmonad_finished)
                self.kmonad_process.errorOccurred.connect(self.on_kmonad_error)
                
                # Run kmonad with config file
                self.kmonad_process.startDetached("kmonad", [config_file])
                
                self.start_button.setText("Stop KMonad")
                
            except Exception as e:
                self.warning_label.setText(f"Error starting KMonad: {str(e)}")
                self.warning_label.show()
            self.update_tray_status(True)
        else:
            # Stop KMonad process
            self.kill_existing_kmonad()
            self.start_button.setText("Start KMonad")
            self.update_tray_status(False)

    def on_kmonad_finished(self, exit_code, exit_status):
        """Handle KMonad process finishing."""
        self.start_button.setText("Start KMonad")
        if exit_code != 0:
            self.warning_label.setText(f"KMonad exited with code {exit_code}")
            self.warning_label.show()

    def on_kmonad_error(self, error):
        """Handle KMonad process errors."""
        self.warning_label.setText(f"KMonad error: {error}")
        self.warning_label.show()

    def check_existing_kmonad(self):
        """Check for existing KMonad processes and update UI accordingly."""
        try:
            # Check for running kmonad processes
            result = subprocess.run(
                ['pgrep', '-a', 'kmonad'],
                capture_output=True,
                text=True
            )
            
            if result.stdout:
                self.kmonad_pid = int(result.stdout.split()[0])
                self.start_button.setText("Stop KMonad")
                # Create process object for existing kmonad
                self.kmonad_process = QProcess()
                self.kmonad_process.setProcessId(self.kmonad_pid)
            else:
                self.kmonad_pid = None
                self.start_button.setText("Start KMonad")
                
        except subprocess.CalledProcessError:
            self.warning_label.setText("Error checking KMonad processes")
            self.warning_label.show()

    def kill_existing_kmonad(self):
        """Kill any existing KMonad processes."""
        try:
            subprocess.run(['pkill', 'kmonad'], check=True)
            return True
        except subprocess.CalledProcessError:
            self.warning_label.setText("Error killing existing KMonad processes")
            self.warning_label.show()
            return False

    def closeEvent(self, event):
        """Handle window close event."""
        if self.minimize_to_tray.isChecked():
            event.ignore()
            self.hide()
        else:
            # Clean up process object but don't kill KMonad
            if self.kmonad_process is not None:
                self.kmonad_process.setParent(None)
                self.kmonad_process = None
            event.accept()

    def create_tray_icon(self):
        """Create system tray icon and menu."""
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(QIcon.fromTheme('input-keyboard'))
        
        # Create tray menu
        self.tray_menu = QMenu()
        
        self.show_action = self.tray_menu.addAction("Show")
        self.show_action.triggered.connect(self.show)
        
        self.toggle_action = self.tray_menu.addAction("Stop KMonad")
        self.toggle_action.triggered.connect(self.toggle_kmonad)
        
        self.tray_menu.addSeparator()
        
        quit_action = self.tray_menu.addAction("Quit")
        quit_action.triggered.connect(self.quit_application)
        
        self.tray_icon.setContextMenu(self.tray_menu)
        self.tray_icon.activated.connect(self.tray_activated)
        
        # Show tray icon
        self.tray_icon.show()
        
    def update_tray_status(self, running=False):
        """Update tray icon tooltip and menu to reflect KMonad status."""
        if running:
            self.tray_icon.setToolTip("KMonad Running")
            self.toggle_action.setText("Stop KMonad")
            # Optional: change icon to indicate running state
            self.tray_icon.setIcon(QIcon.fromTheme('input-keyboard-virtual-on'))
        else:
            self.tray_icon.setToolTip("KMonad Stopped")
            self.toggle_action.setText("Start KMonad")
            self.tray_icon.setIcon(QIcon.fromTheme('input-keyboard'))

    def tray_activated(self, reason):
        """Handle tray icon activation."""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.isVisible():
                self.hide()
            else:
                self.show()
                self.raise_()
                self.activateWindow()

    def quit_application(self):
        """Quit the application."""
        # Optionally kill KMonad before quitting
        if self.kmonad_process is not None:
            reply = QMessageBox.question(
                self,
                "Quit",
                "Stop KMonad before quitting?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel
            )
            if reply == QMessageBox.StandardButton.Cancel:
                return
            if reply == QMessageBox.StandardButton.Yes:
                self.kill_existing_kmonad()
        
        QApplication.quit()

    def update_layout(self, state):
        """Update keyboard layout based on offset toggle."""
        for row_idx in range(self.layout.count() - 3):  # Skip device selector and controls
            row_widget = self.layout.itemAt(row_idx).widget()
            if isinstance(row_widget, QWidget):
                row_layout = row_widget.layout()
                row_name = row_widget.property("row_name")
                
                # Calculate offset for this row
                offset = self.row_offsets.get(row_name, 0) if state else 0
                
                # Update margin to create offset
                row_layout.setContentsMargins(offset, 2, 2, 2)
                row_widget.setContentsMargins(offset, 2, 2, 2)  # Also update widget margins
                
                # Force layout update
                row_widget.updateGeometry()
                self.update()
                
                # Store state for this row
                self.row_states[row_idx] = {
                    'offset': offset,
                    'active': state
                }

    def parse_config(self, config_text):
        """Parse KMonad config and update layout."""
        try:
            # Find the deflayer section
            layer_match = re.search(r'\(deflayer\s+default\s+([\s\S]+?)\)', config_text)
            if not layer_match:
                return
                
            layout_text = layer_match.group(1)
            rows = layout_text.strip().split('\n')
            
            # Update key blocks
            for row_idx, row in enumerate(rows):
                if row_idx >= self.layout.count() - 3:  # Skip device selector and controls
                    break
                    
                row_widget = self.layout.itemAt(row_idx).widget()
                if isinstance(row_widget, QWidget):
                    row_layout = row_widget.layout()
                    keys = row.strip().split()
                    
                    for key_idx, key in enumerate(keys):
                        if key_idx >= row_layout.count() - 1:  # Skip stretch
                            break
                            
                        key_block = row_layout.itemAt(key_idx).widget()
                        if isinstance(key_block, KeyBlock):
                            # Handle special key mappings
                            if key in self.special_keys:
                                key = key.strip('()')  # Remove parentheses from aliases
                            key_block.key = key
                            key_block.setText(key)
                            
        except Exception as e:
            self.warning_label.setText(f"Error parsing config: {str(e)}")
            self.warning_label.show()

    def get_layout_config(self):
        """Get current layout configuration."""
        layout = []
        for row_idx in range(self.layout.count() - 3):  # Skip device selector and controls
            row_widget = self.layout.itemAt(row_idx).widget()
            if isinstance(row_widget, QWidget):
                row_layout = row_widget.layout()
                row_keys = []
                
                for key_idx in range(row_layout.count() - 1):  # Skip stretch
                    key_block = row_layout.itemAt(key_idx).widget()
                    if isinstance(key_block, KeyBlock):
                        row_keys.append(key_block.key)
                        
                layout.append(row_keys)
                
        return layout

    def change_layout(self, layout_name):
        """Change keyboard layout."""
        if layout_name in self.layouts:
            self.default_layout = self.layouts[layout_name]
            # Update visual layout
            self.update_visual_layout()
            # Update config
            if layout_name == "Colemak":
                self.config_edit.setText(
                    self.kmonad_configs["QWERTY-Colemak"].replace(
                        "DEVICE_ID", 
                        self.device_combo.currentText()
                    )
                )

    def update_visual_layout(self):
        """Update visual layout with current mapping."""
        for row_idx in range(self.layout.count() - 3):
            row_widget = self.layout.itemAt(row_idx).widget()
            if isinstance(row_widget, QWidget):
                row_name = row_widget.property("row_name")
                if row_name in self.default_layout:
                    row_layout = row_widget.layout()
                    keys = self.default_layout[row_name]
                    for key_idx, key in enumerate(keys):
                        if key_idx < row_layout.count() - 1:
                            key_block = row_layout.itemAt(key_idx).widget()
                            if isinstance(key_block, KeyBlock):
                                key_block.key = key
                                key_block.setText(key)

class KeyBlock(QLabel):
    """Individual key block widget."""
    
    is_dragging = False  # Class variable to track dragging state

    def __init__(self, key, parent=None):
        super().__init__(parent)
        self.key = key
        self.original_key = key
        self.is_placeholder = False
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedSize(50, 50)
        self.setText(key)
        self.setAcceptDrops(True)
        self.setMouseTracking(True)  # Enable mouse tracking for hover
        
        # Enable animation
        self.animation = QPropertyAnimation(self, b"pos")
        self.animation.setDuration(150)
        self.animation.setEasingCurve(QEasingCurve.Type.OutQuad)
        
        self.update_style()

    def update_style(self, is_active=False, is_target=False, is_neighbor=False, drop_left=False, drop_right=False):
        """Update visual style of key block."""
        if self.is_placeholder:
            bg_color = "#1a1a1a"
            text_color = "#404040"
            border_color = "#2a2a2a"
            border_style = "solid"
        else:
            bg_color = "#2a4a2a" if is_active else "#2a2a2a"
            text_color = "#90ff90" if is_active else "white"
            if drop_left:
                border_left = "4px solid #90ff90"
                border_right = "2px solid #3a3a3a"
            elif drop_right:
                border_left = "2px solid #3a3a3a"
                border_right = "4px solid #90ff90"
            else:
                border_left = border_right = "2px solid " + ("#4a6a4a" if is_target else "#3a3a3a")

            if is_target:
                border_color = "#4a6a4a"
                bg_color = "#3a5a3a"
            elif is_neighbor:
                border_color = "#3a5a3a"
                bg_color = "#2a3a2a"
            else:
                border_color = "#3a3a3a"

        self.setStyleSheet(f"""
            QLabel {{
                background-color: {bg_color};
                color: {text_color};
                border-top: 2px solid {border_color};
                border-bottom: 2px solid {border_color};
                border-left: {border_left if 'border_left' in locals() else '2px solid ' + border_color};
                border-right: {border_right if 'border_right' in locals() else '2px solid ' + border_color};
                border-radius: 4px;
                padding: 8px;
                min-width: 30px;
                min-height: 30px;
                margin: 1px;
            }}
            QLabel:hover {{
                background-color: {"#3a5a3a" if not self.is_placeholder else bg_color};
            }}
        """)

        # Add drop indicator overlay if needed
        if drop_left or drop_right:
            self.setProperty("dropSide", "left" if drop_left else "right")
        else:
            self.setProperty("dropSide", "")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.is_placeholder:
            self.dragStartPosition = event.pos()
            # Start drag immediately without setting dragging state
            drag = QDrag(self)
            mime = QMimeData()
            mime.setText(self.key)
            drag.setMimeData(mime)
            
            pixmap = QPixmap(self.size())
            self.render(pixmap)
            drag.setPixmap(pixmap)
            
            # Set placeholder before starting drag
            self.is_placeholder = True
            self.setText("")
            self.update_style()
            
            # Set dragging state
            KeyBlock.is_dragging = True
            
            result = drag.exec(Qt.DropAction.MoveAction)
            
            # Reset states after drag
            KeyBlock.is_dragging = False
            if result == Qt.DropAction.IgnoreAction:
                self.is_placeholder = False
                self.key = self.original_key
                self.setText(self.key)
                self.update_style()

    def enterEvent(self, event):
        """Handle mouse enter for hover effects."""
        if KeyBlock.is_dragging:
            # Get parent row and spread
            parent_row = self.parent()
            if parent_row:
                row_layout = parent_row.layout()
                # Spread the row
                for i in range(row_layout.count() - 1):
                    key_block = row_layout.itemAt(i).widget()
                    if isinstance(key_block, KeyBlock):
                        new_x = i * (key_block.width() + 20)  # 20px spacing
                        key_block.animate_to(QPoint(new_x, key_block.pos().y()))
                        key_block.update_style(is_target=(key_block == self))

    def leaveEvent(self, event):
        """Handle mouse leave."""
        if KeyBlock.is_dragging:
            # Reset row spacing
            parent_row = self.parent()
            if parent_row:
                row_layout = parent_row.layout()
                for i in range(row_layout.count() - 1):
                    key_block = row_layout.itemAt(i).widget()
                    if isinstance(key_block, KeyBlock):
                        new_x = i * (key_block.width() + 2)  # Normal spacing
                        key_block.animate_to(QPoint(new_x, key_block.pos().y()))
                        key_block.update_style()

    def dragEnterEvent(self, event):
        if event.mimeData().hasText() and KeyBlock.is_dragging:  # Only handle if dragging
            event.accept()
            self.update_style(is_target=True)
            parent_row = self.parent()
            if parent_row:
                self.spread_row(parent_row.layout(), self, -1)

    def dragMoveEvent(self, event):
        if event.mimeData().hasText():
            event.accept()
            parent_row = self.parent()
            if not parent_row:
                return
                
            row_layout = parent_row.layout()
            
            # Calculate drop position
            mouse_x = event.pos().x()
            drop_on_right = mouse_x > self.width() / 2
            
            # Update all keys in row
            for i in range(row_layout.count() - 1):
                key_block = row_layout.itemAt(i).widget()
                if isinstance(key_block, KeyBlock):
                    # Spread positions
                    new_x = i * (key_block.width() + 20)  # Wider spacing during drag
                    key_block.animate_to(QPoint(new_x, key_block.pos().y()))
                    
                    # Update visual style
                    if key_block == self:
                        key_block.update_style(is_target=True, 
                                            drop_left=not drop_on_right,
                                            drop_right=drop_on_right)
                    else:
                        is_neighbor = abs(row_layout.indexOf(key_block) - row_layout.indexOf(self)) == 1
                        key_block.update_style(is_neighbor=is_neighbor)

    def spread_row(self, row_layout, target_block, placeholder_index, drop_on_right=False):
        """Spread keys in a row and highlight target."""
        if not row_layout:
            return
            
        num_keys = row_layout.count() - 1
        base_spacing = 2
        spread_spacing = 20
        target_index = row_layout.indexOf(target_block)
        
        # Get current row offset (for staggered layout)
        row_widget = row_layout.parent()
        current_offset = row_widget.contentsMargins().left()
        
        # Calculate positions with drop indicator
        for i in range(num_keys):
            key_block = row_layout.itemAt(i).widget()
            if isinstance(key_block, KeyBlock):
                # Calculate base position including stagger offset
                base_x = current_offset + (i * (key_block.width() + base_spacing))
                
                # Add spread spacing based on position relative to target
                if i < target_index:
                    new_x = base_x
                elif i == target_index:
                    new_x = base_x + (spread_spacing if not drop_on_right else 0)
                else:
                    new_x = base_x + spread_spacing
                
                # Skip placeholder space
                if placeholder_index >= 0 and i > placeholder_index:
                    new_x -= (key_block.width() + base_spacing)
                
                # Update position and style
                if key_block == target_block:
                    key_block.update_style(is_target=True, 
                                        drop_left=not drop_on_right,
                                        drop_right=drop_on_right)
                else:
                    is_neighbor = abs(i - target_index) == 1
                    key_block.update_style(is_neighbor=is_neighbor)
                
                current_pos = key_block.pos()
                if current_pos.x() != new_x:
                    key_block.animate_to(QPoint(new_x, current_pos.y()))

    def dragLeaveEvent(self, event):
        """Handle drag leave."""
        self.update_style()
        # Reset row spacing
        parent_row = self.parent()
        self.reset_row_spacing(parent_row.layout())

    def dropEvent(self, event):
        if event.mimeData().hasText():
            source = event.source()
            if source != self:
                source_row = source.parent().layout()
                target_row = self.parent().layout()
                source_index = source_row.indexOf(source)
                target_index = target_row.indexOf(self)
                
                # Get drop side
                drop_on_right = event.pos().x() > self.width() / 2
                if drop_on_right:
                    target_index += 1
                
                # Handle same row movement
                if source_row == target_row:
                    # Get all keys
                    keys = []
                    for i in range(source_row.count() - 1):
                        block = source_row.itemAt(i).widget()
                        if isinstance(block, KeyBlock):
                            keys.append(block.key)
                    
                    # Move key to new position
                    key = keys.pop(source_index)
                    keys.insert(target_index if target_index < source_index else target_index - 1, key)
                    
                    # Update all keys
                    for i, key in enumerate(keys):
                        block = source_row.itemAt(i).widget()
                        if isinstance(block, KeyBlock):
                            block.key = key
                            block.setText(key)
                            block.is_placeholder = False
                            block.update_style()
                else:
                    # Different row swap - handle normally
                    new_key = event.mimeData().text()
                    if self.is_placeholder:
                        self.is_placeholder = False
                        self.key = new_key
                    else:
                        source.key = self.key
                        source.setText(self.key)
                        self.key = new_key
                    self.setText(new_key)
                
                # Update KMonad config
                if isinstance(self.parent().parent(), KeyboardLayout):
                    keyboard_layout = self.parent().parent()
                    keyboard_layout.update_config()
                
                # Reset spacing
                self.reset_row_spacing(target_row)
                if source_row != target_row:
                    self.reset_row_spacing(source_row)
            
            event.accept()

    def reset_row_spacing(self, row_layout):
        """Reset spacing for all keys in a row."""
        for i in range(row_layout.count() - 1):
            key_block = row_layout.itemAt(i).widget()
            if isinstance(key_block, KeyBlock):
                original_x = i * (key_block.width() + 2)
                current_pos = key_block.pos()
                if current_pos.x() != original_x:
                    key_block.animate_to(QPoint(original_x, current_pos.y()))

    def animate_to(self, new_pos):
        """Animate key block to new position."""
        if self.pos() == new_pos:
            return
        
        self.animation.stop()
        self.animation.setStartValue(self.pos())
        self.animation.setEndValue(new_pos)
        self.animation.start()

    def startDrag(self):
        """Start the drag operation."""
        drag = QDrag(self)
        mime = QMimeData()
        mime.setText(self.key)
        drag.setMimeData(mime)
        
        pixmap = QPixmap(self.size())
        self.render(pixmap)
        drag.setPixmap(pixmap)
        
        self.is_placeholder = True
        self.setText("")
        self.update_style()
        
        result = drag.exec(Qt.DropAction.MoveAction)
        
        KeyBlock.is_dragging = False  # Reset drag state
        
        if result == Qt.DropAction.IgnoreAction:
            self.is_placeholder = False
            self.key = self.original_key
            self.setText(self.key)
            self.update_style()