"""Keyboard configuration and KMonad management tool"""

__version__ = "0.1.0" 