"""Speech-to-text transcription tool"""

__version__ = "0.1.0" 